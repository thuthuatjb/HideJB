//
//  Headers/FrontBoard/FBApplicationProcess.h
//  LaunchInSafeMode
//
//  Created by inoahdev on 7/2/18.
//  Copyright © 2017 - 2018 inoahdev. All rights reserved.
//

#import "FBApplicationInfo.h"

@interface FBApplicationProcess : NSObject
@property (nonatomic, readonly) FBApplicationInfo *applicationInfo;
@end