//
//  Headers/FrontBoard/FBApplicationInfo.h
//  LaunchInSafeMode
//
//  Created by inoahdev on 7/2/18.
//  Copyright © 2017 - 2018 inoahdev. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FBApplicationInfo : NSObject {
    NSString *_bundleIdentifier;
}
@end